package adp.tcs.automation.locators;

import org.openqa.selenium.By;

/**
 * Created by garghina on 1/10/2017.
 */
public class NotificationLocators {
    public static By UrgentTile_link=By.xpath("//DIV[@class='activity-tile activity-tile--urgent']");
    public static By Confirmation_number=By.xpath("(//DT[text()='CONFIRMATION'][text()='CONFIRMATION'])[3]");
    
}
