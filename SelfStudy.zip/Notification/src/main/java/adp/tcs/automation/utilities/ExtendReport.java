package adp.tcs.automation.utilities;

import com.relevantcodes.extentreports.ExtentTest;

/**
 * Created by bhutesac on 8/8/2016.
 */
public class ExtendReport {

    public ExtentTest logger;


}
