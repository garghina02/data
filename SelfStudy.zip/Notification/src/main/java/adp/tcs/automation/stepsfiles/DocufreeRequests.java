package adp.tcs.automation.stepsfiles;

import adp.tcs.automation.utilities.randomSSNgenrater;

/**
 * Created by Thorasa on 09/29/2016.
 */
public class DocufreeRequests extends BaseTempletSteps{

	randomSSNgenrater ssnGenerator = new randomSSNgenrater();
	
	// Docufree Eligible Request
    public String docufreeEligibleRequest() {
    	String SSN = String.valueOf(ssnGenerator.generateSSN());
    	String uniqueId = String.valueOf(ssnGenerator.generateUniqueIdForDocufree());
		final String request;
    	getExcelData().put("SSN", SSN);
    	getExcelData().put("CSSN", SSN);
    	getExcelData().put("UNIQUE_ID", uniqueId);
		if(getExcelData().get("HIRE_CURRENT_DATE").equals("YES")){
			request = "<?xml version='1.0' encoding='ISO-8859-1' ?><DocuFree><identification><client>" + getExcelData().get("CLIENT_ID") + "</client><company>" + getExcelData().get("COMPANY_ID") + "</company><UniqueID>" + getExcelData().get("UNIQUE_ID") + "</UniqueID><ImagePath>DOCUFREE_URL_TO_IMAGE</ImagePath><queue>Docufree</queue></identification><data><stepinf id='SSN'>" + getExcelData().get("SSN") + "</stepinf><stepinf id='First Name'>" + getExcelData().get("FNAME") + "</stepinf><stepinf id='Last Name'>" + getExcelData().get("LNAME") + "</stepinf><stepinf id='Hire Date'>" + currentdate() + "</stepinf><stepinf id='Start Date'>" + currentdate() + "</stepinf><stepinf id='Street Address'>" + getExcelData().get("HOME_STREET_ADDRESS") + "</stepinf><stepinf id='Zip'>" + getExcelData().get("ZIP") + "</stepinf><stepinf id='City'>" + getExcelData().get("CITY") + "</stepinf><stepinf id='State'>" + getExcelData().get("STATE") + "</stepinf><stepinf id='Date of Birth'>" + getExcelData().get("DOB") + "</stepinf><stepinf id='Veteran'>" + getExcelData().get("VETERAN") + "</stepinf>   <stepinf id='Military_Disable'>" + getExcelData().get("MILITARY_DISABLE") + "</stepinf>   <stepinf id='Military_DR'>" + getExcelData().get("MILITARY_DR") + "</stepinf>  <stepinf id='UVET_COMP_4W'>" + getExcelData().get("UVET_COMP_4W") + "</stepinf>   <stepinf id='UVET_COMP_6M'>" + getExcelData().get("UVET_COMP_6M") + "</stepinf>   <stepinf id='Vet Food Stamps'>" + getExcelData().get("VET_FOOD_STAMPS") + "</stepinf>   <stepinf id='Vocation Rehab Question'>" + getExcelData().get("VOCATION_REHAB_QUESTION") + "</stepinf><stepinf id='WOTC Not Eligible'>" + getExcelData().get("WOTC_NOT_ELIGIBLE") + "</stepinf><stepinf id='SSI'>" + getExcelData().get("SSI_QUE") + "</stepinf><stepinf id='SSDI'>" + getExcelData().get("SSDI_QUE") + "</stepinf><stepinf id='FELONY GENERAL'>" + getExcelData().get("FELONY_GENERAL") + "</stepinf>   <stepinf id='FELONY REL'>" + getExcelData().get("FELONY_REL") + "</stepinf><stepinf id='unemp_6_month'>" + getExcelData().get("UNEMP_6_MONTH") + "</stepinf><stepinf id='unemp_benefic'>" + getExcelData().get("UNEMP_BENEFIC") + "</stepinf></data></DocuFree>";
		}else {
			request = "<?xml version='1.0' encoding='ISO-8859-1' ?><DocuFree><identification><client>" + getExcelData().get("CLIENT_ID") + "</client><company>" + getExcelData().get("COMPANY_ID") + "</company><UniqueID>" + getExcelData().get("UNIQUE_ID") + "</UniqueID><ImagePath>DOCUFREE_URL_TO_IMAGE</ImagePath><queue>Docufree</queue></identification><data><stepinf id='SSN'>" + getExcelData().get("SSN") + "</stepinf><stepinf id='First Name'>" + getExcelData().get("FNAME") + "</stepinf><stepinf id='Last Name'>" + getExcelData().get("LNAME") + "</stepinf><stepinf id='Hire Date'>" + getExcelData().get("HIRE_DATE") + "</stepinf><stepinf id='Start Date'>" + getExcelData().get("HIRE_START_DATE") + "</stepinf><stepinf id='Street Address'>" + getExcelData().get("HOME_STREET_ADDRESS") + "</stepinf><stepinf id='Zip'>" + getExcelData().get("ZIP") + "</stepinf><stepinf id='City'>" + getExcelData().get("CITY") + "</stepinf><stepinf id='State'>" + getExcelData().get("STATE") + "</stepinf><stepinf id='Date of Birth'>" + getExcelData().get("DOB") + "</stepinf><stepinf id='Veteran'>" + getExcelData().get("VETERAN") + "</stepinf>   <stepinf id='Military_Disable'>" + getExcelData().get("MILITARY_DISABLE") + "</stepinf>   <stepinf id='Military_DR'>" + getExcelData().get("MILITARY_DR") + "</stepinf>  <stepinf id='UVET_COMP_4W'>" + getExcelData().get("UVET_COMP_4W") + "</stepinf>   <stepinf id='UVET_COMP_6M'>" + getExcelData().get("UVET_COMP_6M") + "</stepinf>   <stepinf id='Vet Food Stamps'>" + getExcelData().get("VET_FOOD_STAMPS") + "</stepinf>   <stepinf id='Vocation Rehab Question'>" + getExcelData().get("VOCATION_REHAB_QUESTION") + "</stepinf><stepinf id='WOTC Not Eligible'>" + getExcelData().get("WOTC_NOT_ELIGIBLE") + "</stepinf><stepinf id='SSI'>" + getExcelData().get("SSI_QUE") + "</stepinf><stepinf id='SSDI'>" + getExcelData().get("SSDI_QUE") + "</stepinf><stepinf id='FELONY GENERAL'>" + getExcelData().get("FELONY_GENERAL") + "</stepinf>   <stepinf id='FELONY REL'>" + getExcelData().get("FELONY_REL") + "</stepinf><stepinf id='unemp_6_month'>" + getExcelData().get("UNEMP_6_MONTH") + "</stepinf><stepinf id='unemp_benefic'>" + getExcelData().get("UNEMP_BENEFIC") + "</stepinf></data></DocuFree>";
		}
		return request;
    }       
	
 // Docufree InEligible Request
    public String docufreeIneligibleRequest() {
    	String SSN = String.valueOf(ssnGenerator.generateSSN());
    	String uniqueId = String.valueOf(ssnGenerator.generateUniqueIdForDocufree());
    	getExcelData().put("SSN", SSN);
    	getExcelData().put("CSSN", SSN);
    	getExcelData().put("UNIQUE_ID", uniqueId);
    	final String request = "<?xml version='1.0' encoding='ISO-8859-1' ?><DocuFree><identification><client>"+getExcelData().get("CLIENT_ID")+"</client><company>"+getExcelData().get("COMPANY_ID")+"</company><UniqueID>"+getExcelData().get("UNIQUE_ID")+"</UniqueID><ImagePath>DOCUFREE_URL_TO_IMAGE</ImagePath><queue>Docufree</queue></identification><data><stepinf id='SSN'>"+getExcelData().get("SSN")+"</stepinf><stepinf id='First Name'>"+getExcelData().get("FNAME")+"</stepinf><stepinf id='Last Name'>"+getExcelData().get("LNAME")+"</stepinf><stepinf id='Hire Date'>"+getExcelData().get("HIRE_DATE")+"</stepinf><stepinf id='Start Date'>"+getExcelData().get("HIRE_START_DATE")+"</stepinf></data></DocuFree>";
        return request;
    }
    
 // Docufree Incomplete Request
    public String docufreeIncompleteRequest() {    	
    	String uniqueId = String.valueOf(ssnGenerator.generateUniqueIdForDocufree());
    	if(getExcelData().get("SSN").equals("")){
    		String SSN = String.valueOf(ssnGenerator.generateSSN());
    		getExcelData().put("SSN", SSN);
        	getExcelData().put("CSSN", SSN);
    	}    	
    	getExcelData().put("UNIQUE_ID", uniqueId);
    	final String request = "<?xml version='1.0' encoding='ISO-8859-1' ?><DocuFree><identification><client>"+getExcelData().get("CLIENT_ID")+"</client><company>"+getExcelData().get("COMPANY_ID")+"</company><UniqueID>"+getExcelData().get("UNIQUE_ID")+"</UniqueID><ImagePath>DOCUFREE_URL_TO_IMAGE</ImagePath><queue>Docufree</queue></identification><data><stepinf id='SSN'>"+getExcelData().get("SSN")+"</stepinf><stepinf id='First Name'>"+getExcelData().get("FNAME")+"</stepinf><stepinf id='Last Name'>"+getExcelData().get("LNAME")+"</stepinf><stepinf id='Hire Date'>"+getExcelData().get("HIRE_DATE")+"</stepinf><stepinf id='Start Date'>"+getExcelData().get("HIRE_START_DATE")+"</stepinf><stepinf id='Street Address'>"+getExcelData().get("HOME_STREET_ADDRESS")+"</stepinf><stepinf id='Zip'>"+getExcelData().get("ZIP")+"</stepinf><stepinf id='City'>"+getExcelData().get("CITY")+"</stepinf><stepinf id='State'>"+getExcelData().get("STATE")+"</stepinf><stepinf id='Date of Birth'>"+getExcelData().get("DOB")+"</stepinf></data></DocuFree>";
        return request;
    }
    
}
