package adp.tcs.automation.stepsfiles;

import adp.tcs.automation.locators.SearchSSNHub;
import adp.tcs.automation.pages.MonitoringPages;
import adp.tcs.automation.pages.SearchSSNthroughHub;
import adp.tcs.automation.utilities.ServiceCallResponse;
import adp.tcs.automation.utilities.TakeScreenshotAction;
import adp.tcs.automation.utilities.WndowAction;
import org.jbehave.core.annotations.Aliases;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.When;

/**
 * Created by Thorasa on 09/29/2016.
 */
public class DcoufreeSteps extends BaseTempletSteps{

	private String requestMethodType = "POST";
    private String requestContentType = "application/xml";
    private String responseContentType = "";
    private final ServiceCallResponse callResponse = new ServiceCallResponse();
    private final DocufreeRequests docufreeRequests = new DocufreeRequests();
    private final SearchSSNthroughHub hub = new SearchSSNthroughHub();
    private final WndowAction windowAct = new WndowAction();
    private final MonitoringPages monitorElements = new MonitoringPages();
    private final HubValidationsSteps hubValidation = new HubValidationsSteps();
	private TakeScreenshotAction screenshot = new TakeScreenshotAction();
    
    @When("Perform Docufree screening for eligible record")
	public void docufreeEligible() throws Exception{
		try {
			verifyTest("Perform Docufree screening for eligible record");
			String hireResponse = callResponse.getResponseForDocufree(getExcelData().get("REST_URL"), requestMethodType, requestContentType, responseContentType, getExcelData().get("COOKIES"), getExcelData().get("AUTHORIZATION_CODE"), docufreeRequests.docufreeEligibleRequest());
			String confNumber = getTagValue(hireResponse, "/DocuFree/@status");
			if (!confNumber.equals("OK")) {
				verifyTest("Invalid docufree resonse ", false);
			}
		} catch (Exception e) {
			screenshot.getScreenshot("docufreeEligible");
			e.printStackTrace();
			verifyTest("Perform Docufree screening for eligible record : docufreeEligible() ", false);
		}
	}
    
    @When("Perform Docufree screening for Ineligible record")
	public void docufreeIneligible() throws Exception {
		try {
			verifyTest("Perform Docufree screening for Ineligible record");
			String hireResponse = callResponse.getResponseForDocufree(getExcelData().get("REST_URL"), requestMethodType, requestContentType, responseContentType, getExcelData().get("COOKIES"), getExcelData().get("AUTHORIZATION_CODE"), docufreeRequests.docufreeIneligibleRequest());
			String confNumber = getTagValue(hireResponse, "/DocuFree/@status");
			if (!confNumber.equals("OK")) {
				verifyTest("Invalid docufree resonse", false);
			}
		} catch (Exception e) {
			screenshot.getScreenshot("docufreeIneligible");
			e.printStackTrace();
			verifyTest("Perform Docufree screening for Ineligible record : docufreeIneligible()", false);
		}
	}
    
    @When("Perform Docufree screening for Invalid Start Date")
    @Aliases(values={"Perform Docufree screening for Invalid Hire Date",
    		"Perform Docufree screening for Invalid SSN",
    		"Perform Docufree screening for Invalid Client Id",
    		"Perform Docufree screening for Invalid Company Id"})
	public void docufreeInvalidRequest() throws Exception{
		try {
			verifyTest("Perform Docufree screening for invalid request");
			String hireResponse = callResponse.getResponseForDocufree(getExcelData().get("REST_URL"), requestMethodType, requestContentType, responseContentType, getExcelData().get("COOKIES"), getExcelData().get("AUTHORIZATION_CODE"), docufreeRequests.docufreeIncompleteRequest());
			String confNumber = getTagValue(hireResponse, "/DocuFree/@status");
			if (!confNumber.equals("OK")) {
				verifyTest("Invalid docufree resonse", false);
			}
		} catch (Exception e) {
			screenshot.getScreenshot("docufreeIneligible");
			e.printStackTrace();
			verifyTest("Perform Docufree screening : docufreeInvalidRequest() ", false);
		}
	}
    
    
    
    @When("Verify the record in monitoring section")
    public void verifyRecordInMonitoring(@Named("errorDescription") String errorDescriptionExpected) throws Exception{
		try {
			verifyTest("Verify the record in monitoring section");
			gotoHubPage();
			monitorElements.data_Entry_Link().click();
			monitorElements.monitoring_Link().click();		
			monitorElements.unique_Id_Text_Field_Monitoring().sendKeys(getExcelData().get("UNIQUE_ID"));
			monitorElements.search_Btn_Monitoring().click();			
			String errorDiscription = monitorElements.search_Result_Error_Desc_Field().getText();			
			if (!errorDiscription.equals(errorDescriptionExpected)) {
				verifyTest("Error Desciption is not matching : ACTUAL = " + errorDiscription + ", EXPECTED = "+ errorDescriptionExpected, false);
			}
		} catch (Exception e) {
			screenshot.getScreenshot("docufreeIneligible");
			e.printStackTrace();
			verifyTest("Verify the record in monitoring section : verifyRecordInMonitoring()", false);
		}
	}
    
    public void gotoHubPage() throws Exception{
		try {
//			hub.Search_SSN_Process_Tab().click();
//			hub.Search_SSN_Process_Tax_Credit_Tab().click();
//			hub.Search_SSN_Process_Tax_Credit_Operation_Tab().click();
//	        explicitWaitForElement(SearchSSNHub.SEARCH_SSN_THE_HUB_LINK,65);
//	        WebElement hubLink = hub.Search_SSN_The_Hub_Link();
//	        Thread.sleep(2000);
//	        windowAct.switchtoMultiChildWindow(hubLink);
//	        explicitWaitForElement(SearchSSNHub.SEARCH_SSN_INPUTBOX,65);
			 	sleep(2000);
		        waitForLoad();
		        explicitWaitForElement(SearchSSNHub.SELECT_OPERATION_TAB,65);
		        hub.CAPS_QA_ENVIRONEMT_Operation_Tab_Chg().click();
		        sleep(2000);
		        explicitWaitForElement(SearchSSNHub.THE_HUB_LINK,65);        
		        Thread.sleep(2000);
		        windowAct.switchtoMultiChildWindow(hub.CAPS_QA_Hub_New_Link());
		        explicitWaitForElement(SearchSSNHub.SEARCH_SSN_INPUTBOX,65);
		        sleep(2000);
		} catch (Exception e) {
			screenshot.getScreenshot("gotoHubPage");
			e.printStackTrace();
			verifyTest("User is in hub page -- gotoHubPage() ", false);
		}
	}
    
    @When("Verify the Record in hub search page")
    public void verifyRecordInHubSearchWithStatus() throws Exception {
		try {
			verifyTest("Verify the Record in hub search page");
			gotoHubPage();
			hubValidation.performHubSearch();
			sleep(2000);
			hubValidation.verifyHubeSearchResult();			
		} catch (Exception e) {
			screenshot.getScreenshot("verifyRecordInHubSearchWithStatus");
			e.printStackTrace();
			verifyTest("User is in hub page -- gotoHubPage() ", false);
		}
	}
    
    
    
}
